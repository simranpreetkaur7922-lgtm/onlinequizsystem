#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <limits>
#include <iomanip>
#include <ctime>
using namespace std;

// -------------------- OOPS: Question Class --------------------
class Question {
private:
    int id;
    string text, options[4], correctOption;

public:
    Question() : id(0) {}

    Question(int qid, string q, string a, string b, string c, string d, string ans) {
        id = qid; text = q;
        options[0] = a; options[1] = b; options[2] = c; options[3] = d;
        correctOption = ans;
    }

    void display() const {
        cout << "\n" << text << "\n";
        for (int i = 0; i < 4; i++)
            cout << char('A' + i) << ". " << options[i] << "\n";
    }

    bool isCorrect(string answer) const {
        return answer == correctOption;
    }

    int getId() const { return id; }
    string getText() const { return text; }
    string getOption(int i) const { return options[i]; }
    string getAnswer() const { return correctOption; }

    string toFileLine() const {
        return to_string(id) + "|" + text + "|" + options[0] + "|" +
               options[1] + "|" + options[2] + "|" + options[3] + "|" + correctOption;
    }

    bool fromFileLine(const string &line) {
        string fields[7];
        stringstream ss(line);
        for (int i = 0; i < 7; i++) {
            if (!getline(ss, fields[i], '|')) return false;
        }
        id = atoi(fields[0].c_str());
        text = fields[1];
        for (int i = 0; i < 4; i++) options[i] = fields[i + 2];
        correctOption = fields[6];
        return true;
    }
};

// -------------------- OOPS: Result Class --------------------
class Result {
private:
    string studentName, dateTime;
    int totalQuestions, score;

public:
    Result(string name, int total, int marks) {
        studentName = name;
        totalQuestions = total;
        score = marks;
        time_t now = time(0);
        dateTime = ctime(&now);
        if (!dateTime.empty() && dateTime[dateTime.size()-1] == '\n')
            dateTime.erase(dateTime.size()-1);
    }

    void save() const {
        ofstream file("results.txt", ios::app);
        if (file)
            file << studentName << "|" << score << "|" << totalQuestions
                 << "|" << dateTime << "\n";
    }

    void display() const {
        double percentage = totalQuestions ? (score * 100.0 / totalQuestions) : 0;
        cout << "\n========== QUIZ RESULT ==========\n";
        cout << "Student       : " << studentName << "\n";
        cout << "Score         : " << score << "/" << totalQuestions << "\n";
        cout << "Percentage    : " << fixed << setprecision(2) << percentage << "%\n";
        cout << "=================================\n";
    }
};

// -------------------- OOPS: Quiz Class --------------------
class Quiz {
private:
    vector<Question> questions;

public:
    void loadQuestions() {
        questions.clear();
        ifstream file("questions.txt");
        string line;
        while (getline(file, line)) {
            Question q;
            if (q.fromFileLine(line)) questions.push_back(q);
        }
    }

    void showQuestions() const {
        if (questions.empty()) {
            cout << "\nNo questions available.\n";
            return;
        }
        cout << "\n--------- QUESTION BANK ---------\n";
        for (size_t i = 0; i < questions.size(); i++) {
            cout << "\nQ" << i + 1 << ". " << questions[i].getText() << "\n";
            for (int j = 0; j < 4; j++)
                cout << char('A' + j) << ". " << questions[i].getOption(j) << "\n";
            cout << "Correct answer: " << questions[i].getAnswer() << "\n";
        }
    }

    void addQuestion() {
        string q, a, b, c, d, ans;
        int nextId = 1;
        for (size_t i = 0; i < questions.size(); i++)
            if (questions[i].getId() >= nextId) nextId = questions[i].getId() + 1;

        cout << "\nEnter question: ";
        getline(cin, q);
        cout << "Option A: "; getline(cin, a);
        cout << "Option B: "; getline(cin, b);
        cout << "Option C: "; getline(cin, c);
        cout << "Option D: "; getline(cin, d);
        do {
            cout << "Correct option (A/B/C/D): ";
            getline(cin, ans);
            for (size_t i = 0; i < ans.size(); i++) ans[i] = (char)toupper(ans[i]);
        } while (ans != "A" && ans != "B" && ans != "C" && ans != "D");

        ofstream file("questions.txt", ios::app);
        if (file) {
            Question newQuestion(nextId, q, a, b, c, d, ans);
            file << newQuestion.toFileLine() << "\n";
            cout << "\nQuestion added successfully!\n";
        } else {
            cout << "\nUnable to open questions file.\n";
        }
        loadQuestions();
    }

    void deleteQuestion() {
        if (questions.empty()) {
            cout << "\nNo questions to delete.\n";
            return;
        }
        showQuestions();
        int id;
        cout << "\nEnter Question ID to delete: ";
        cin >> id;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        ofstream file("questions_temp.txt");
        bool found = false;
        for (size_t i = 0; i < questions.size(); i++) {
            if (questions[i].getId() == id) found = true;
            else file << questions[i].toFileLine() << "\n";
        }
        file.close();

        if (found) {
            remove("questions.txt");
            rename("questions_temp.txt", "questions.txt");
            cout << "\nQuestion deleted successfully.\n";
        } else {
            remove("questions_temp.txt");
            cout << "\nQuestion ID not found.\n";
        }
        loadQuestions();
    }

    void start(string studentName) {
        loadQuestions();
        if (questions.empty()) {
            cout << "\nQuiz cannot start because no questions are available.\n";
            return;
        }
        int score = 0;
        cout << "\n========== QUIZ STARTED ==========\n";
        cout << "Choose A, B, C or D for each question.\n";
        for (size_t i = 0; i < questions.size(); i++) {
            questions[i].display();
            string answer;
            do {
                cout << "Your answer: ";
                getline(cin, answer);
                for (size_t j = 0; j < answer.size(); j++)
                    answer[j] = (char)toupper(answer[j]);
            } while (answer != "A" && answer != "B" && answer != "C" && answer != "D");

            if (questions[i].isCorrect(answer)) {
                cout << "Correct!\n";
                score++;
            } else {
                cout << "Incorrect. Correct answer: " << questions[i].getAnswer() << "\n";
            }
        }
        Result result(studentName, (int)questions.size(), score);
        result.display();
        result.save();
        cout << "Your result has been saved.\n";
    }
};

// -------------------- OOPS: User Base Class --------------------
class User {
protected:
    string username;
public:
    User(string name = "") { username = name; }
    virtual void showRole() const = 0; // Runtime polymorphism
    string getUsername() const { return username; }
    virtual ~User() {}
};

// -------------------- Inheritance: Student --------------------
class Student : public User {
public:
    Student(string name) : User(name) {}
    void showRole() const { cout << "Logged in as Student\n"; }
};

// -------------------- Inheritance: Admin --------------------
class Admin : public User {
private:
    string password;
public:
    Admin(string name, string pass) : User(name), password(pass) {}
    bool authenticate(string name, string pass) const {
        return name == username && pass == password;
    }
    void showRole() const { cout << "Logged in as Administrator\n"; }
};

// -------------------- Main Application / Frontend --------------------
class QuizSystem {
private:
    Quiz quiz;

    void adminMenu() {
        string name, pass;
        cout << "\nAdmin username: "; getline(cin, name);
        cout << "Admin password: "; getline(cin, pass);
        Admin admin("admin", "admin123");

        if (!admin.authenticate(name, pass)) {
            cout << "\nInvalid admin credentials.\n";
            return;
        }
        admin.showRole();
        int choice;
        do {
            cout << "\n========== ADMIN PANEL ==========\n";
            cout << "1. Add Question\n2. View Questions\n3. Delete Question\n4. View Student Results\n0. Logout\n";
            cout << "Enter choice: ";
            if (!(cin >> choice)) { cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n'); choice = -1; }
            else cin.ignore(numeric_limits<streamsize>::max(), '\n');

            switch (choice) {
                case 1: quiz.loadQuestions(); quiz.addQuestion(); break;
                case 2: quiz.loadQuestions(); quiz.showQuestions(); break;
                case 3: quiz.loadQuestions(); quiz.deleteQuestion(); break;
                case 4: viewResults(); break;
                case 0: cout << "Admin logged out.\n"; break;
                default: cout << "Invalid choice. Try again.\n";
            }
        } while (choice != 0);
    }

    void viewResults() {
        ifstream file("results.txt");
        string line;
        cout << "\n========== STUDENT RESULTS ==========\n";
        if (!file) { cout << "No results found.\n"; return; }
        while (getline(file, line)) {
            string fields[4];
            stringstream ss(line);
            for (int i = 0; i < 4; i++) getline(ss, fields[i], '|');
            if (!fields[0].empty())
                cout << "Student: " << fields[0] << " | Score: " << fields[1]
                     << "/" << fields[2] << " | Date: " << fields[3] << "\n";
        }
    }

    void studentMenu() {
        string name;
        cout << "\nEnter your name: ";
        getline(cin, name);
        if (name.empty()) { cout << "Name cannot be empty.\n"; return; }
        Student student(name);
        student.showRole();
        int choice;
        do {
            cout << "\n========== STUDENT PANEL ==========\n";
            cout << "1. Start Quiz\n2. View My Previous Results\n0. Logout\n";
            cout << "Enter choice: ";
            if (!(cin >> choice)) { cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n'); choice = -1; }
            else cin.ignore(numeric_limits<streamsize>::max(), '\n');
            switch (choice) {
                case 1: quiz.start(student.getUsername()); break;
                case 2: viewMyResults(student.getUsername()); break;
                case 0: cout << "Student logged out.\n"; break;
                default: cout << "Invalid choice. Try again.\n";
            }
        } while (choice != 0);
    }

    void viewMyResults(string name) {
        ifstream file("results.txt");
        string line;
        bool found = false;
        cout << "\n------ MY PREVIOUS RESULTS ------\n";
        while (getline(file, line)) {
            string fields[4];
            stringstream ss(line);
            for (int i = 0; i < 4; i++) getline(ss, fields[i], '|');
            if (fields[0] == name) {
                found = true;
                cout << "Score: " << fields[1] << "/" << fields[2]
                     << " | Date: " << fields[3] << "\n";
            }
        }
        if (!found) cout << "No previous results found.\n";
    }

public:
    void run() {
        int choice;
        do {
            cout << "\n====================================\n";
            cout << "       ONLINE QUIZ SYSTEM\n";
            cout << "====================================\n";
            cout << "1. Student Login\n2. Admin Login\n0. Exit\n";
            cout << "Enter choice: ";
            if (!(cin >> choice)) { cin.clear(); cin.ignore(numeric_limits<streamsize>::max(), '\n'); choice = -1; }
            else cin.ignore(numeric_limits<streamsize>::max(), '\n');
            switch (choice) {
                case 1: studentMenu(); break;
                case 2: adminMenu(); break;
                case 0: cout << "\nThank you for using Online Quiz System!\n"; break;
                default: cout << "\nInvalid choice. Please try again.\n";
            }
        } while (choice != 0);
    }
};

int main() {
    QuizSystem system;
    system.run();
    return 0;
}
