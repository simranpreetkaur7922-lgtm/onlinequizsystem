# ONLINE QUIZ SYSTEM
## BCA - Object Oriented Programming using C++

### 1. Introduction
The Online Quiz System is a C++ application designed to conduct multiple-choice
quizzes in a simple and organized way. It provides separate menus for students
and administrators. Students can attempt questions and view their scores,
while the administrator can manage the question bank and view student results.

### 2. Objectives
- To conduct objective-type quizzes through a computer application.
- To calculate marks and percentage automatically.
- To allow an administrator to add, view and delete questions.
- To store questions and results permanently using file handling.
- To apply Object-Oriented Programming concepts in a practical project.

### 3. Scope of the Project
The system is suitable for a small educational environment or a classroom
demonstration. It supports one administrator account and multiple student
names. Questions and results are stored in text files, so the information
remains available after the program is closed.

### 4. Software and Hardware Requirements
**Software:** Windows 10/11, Visual Studio Code (optional), MinGW g++ compiler,
C++11 or later.

**Hardware:** A computer with a basic processor, 2 GB or more RAM and sufficient
storage for the source code and data files.

### 5. Main Modules
**Student Module:** Student enters a name, starts the quiz, selects an answer
from four options, receives immediate answer feedback and sees the final score.

**Admin Module:** Administrator logs in using the default credentials and can
add new questions, view the question bank, delete a question by ID and view
saved student results.

**Result Module:** The system calculates the score and percentage and stores
the student's name, marks and date/time in `results.txt`.

**File Management Module:** Questions are read from and written to
`questions.txt`; results are appended to `results.txt`.

### 6. OOPS Concepts Used
- **Class and Object:** The project uses classes such as Question, Quiz, Result,
  User, Student, Admin and QuizSystem.
- **Encapsulation:** Data members are kept private or protected and are
  accessed through public member functions.
- **Inheritance:** Student and Admin are derived from the User base class.
- **Polymorphism:** The virtual `showRole()` method is overridden in Student
  and Admin. User is an abstract class.
- **Constructor:** Constructors initialize class objects.
- **File Handling:** File streams store and retrieve question and result data.

### 7. Working of the System
1. The application displays the main menu.
2. The user selects Student Login or Admin Login.
3. A student enters a name and chooses Start Quiz.
4. Questions are displayed one by one with four options.
5. The program checks each answer and calculates the score.
6. The final result is displayed and saved.
7. The administrator can manage questions and view saved results.

### 8. Limitations and Future Scope
The current version is a console-based academic project. It does not use a
database, network server, browser interface or online multi-user connectivity.
In future, it can be extended with a graphical interface, database storage,
timer, categories, randomized questions, negative marking and secure user
accounts.

### 9. Conclusion
The Online Quiz System demonstrates how C++ and OOPS concepts can be used to
build a useful application. It reduces manual checking by calculating results
automatically and uses file handling to preserve quiz data. The project
provides practical experience with classes, inheritance, polymorphism,
constructors and file operations.
