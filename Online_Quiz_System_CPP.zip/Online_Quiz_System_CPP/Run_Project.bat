@echo off
g++ main.cpp -o OnlineQuiz.exe
if errorlevel 1 pause & exit /b
OnlineQuiz.exe
pause
